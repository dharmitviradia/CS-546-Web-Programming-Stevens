const array= require ("./arrayUtils")
const string= require ("./stringUtils.js")
const obj= require ("./objUtils.js")



try 
    {
        array.arrayHead([1, 2, 3])
        console.log('Head test case passed successfully')
    }
catch (error)
    {
        console.log('Head test case failed')
    }

try 
    {
        array.arrayHead('banana')
        console.log('Head test case passed successfully')
    }
catch (error)
    {
        console.log('Head test case failed')
    }


try 
    {
        array.arrayCount([13, '13', 13, 'hello', true, true])
        console.log('Array Count test case passed successfully')
    }
catch (error)
    {
        console.log('Array Count test case failed')
    }

try 
    {
        array.arrayCount([])
        console.log('Array Count test case passed successfully')
    }
catch (error)
    {
        console.log('Array Count test case failed')
    }


try 
    {
        string.Rep('abc', 3)
        console.log('String Repeat test case passed successfully')
    }
catch (error)
    {
        console.log('String Repeat test case failed')
    }
    
try 
    {
        string.Rep()
        console.log('String Repeat test case passed successfully')
    }
catch (error)
    {
        console.log('String Repeat test case failed')
    }


try 
    {
        obj.mapobj({ a: 1, b: 2, c: 3 }, n => n + 1)
        console.log('MapObject test case passed successfully')
    }
catch (error)
    {
        console.log('MapObject test case failed')
    }

try 
    {
        obj.mapobj()
        console.log('MapObject test case passed successfully')
    }
catch (error)
    {
        console.log('MapObject test case failed')
    }