module.exports = {
    search: require("./people")
  }