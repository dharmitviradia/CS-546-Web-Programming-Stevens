const animalsData = require('./animals')
const postsData = require('./posts')
// const likesData = require('./likes')

module.exports = 
{
  animals: animalsData,
  posts: postsData,
  // likes: likesData
}
