const dictionary = require("./dictionary");
 const dic = require ('./dictionary')
try {
   // console.log(dictionary.lookupDefinition("programming"))
    console.log (dic.lookupDefination("Programming"))
  
}catch (error){
    console.log(error)
}

try{
    console.log(dictionary.getWord("The action or process of writing computer programs."))
}catch (error){
    console.log(error)
}