const PeopleData = require("./people.js")

module.exports = {
  people: PeopleData
}